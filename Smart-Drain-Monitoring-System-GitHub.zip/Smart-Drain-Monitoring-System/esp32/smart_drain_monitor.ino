#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

const int TRIG_PIN = 5;
const int ECHO_PIN = 18; // Connect through a voltage divider; ESP32 GPIO is not 5V tolerant.
const int BUZZER_PIN = 19;
const int RED_LED_PIN = 23;
const float ALERT_DISTANCE_CM = 15.0; // Demo threshold; calibrate before use.

void showStatus(float distanceCm, bool alert) {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.println("SMART DRAIN");
  display.setCursor(0, 20);
  display.print("Distance: ");
  if (distanceCm > 0) {
    display.print(distanceCm, 1);
    display.println(" cm");
  } else {
    display.println("No echo");
  }
  display.setCursor(0, 44);
  display.println(alert ? "BLOCKAGE ALERT!" : "STATUS: MONITORING");
  display.display();
}

void setup() {
  Serial.begin(115200);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(RED_LED_PIN, OUTPUT);
  digitalWrite(TRIG_PIN, LOW);
  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(RED_LED_PIN, LOW);

  Wire.begin(21, 22);
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("OLED not found at I2C address 0x3C.");
    while (true) delay(100);
  }

  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(2);
  display.setCursor(5, 12);
  display.println("SMART");
  display.setCursor(5, 36);
  display.println("DRAIN");
  display.display();
  delay(1500);
}

void loop() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  unsigned long duration = pulseIn(ECHO_PIN, HIGH, 30000UL);
  float distanceCm = duration > 0 ? (duration * 0.0343f / 2.0f) : -1.0f;
  bool alert = (distanceCm > 0 && distanceCm <= ALERT_DISTANCE_CM);

  digitalWrite(BUZZER_PIN, alert ? HIGH : LOW);
  digitalWrite(RED_LED_PIN, alert ? HIGH : LOW);
  showStatus(distanceCm, alert);

  Serial.print("Distance_cm=");
  Serial.print(distanceCm);
  Serial.print(", status=");
  Serial.println(alert ? "BLOCKAGE_ALERT" : "MONITORING");
  delay(500);
}
