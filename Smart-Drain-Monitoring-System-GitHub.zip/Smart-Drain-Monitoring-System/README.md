# Smart Drain Monitoring System

ESP32-based drainage monitoring prototype with an HC-SR04 ultrasonic sensor, SSD1306 I2C OLED, buzzer, and LED. Includes a browser dashboard demo.

## Features
- Reads ultrasonic distance and displays it on the OLED.
- Turns on buzzer and red LED when distance is at or below the configured threshold.
- Includes a corporation-style dashboard with simulated status buttons.
- **Important:** The dashboard is demo-only and is not yet connected to ESP32/Firebase or a real corporation office. Wi-Fi/Firebase integration is a future step.

## Hardware
- ESP32 DevKit / ESP-WROOM-32
- HC-SR04 ultrasonic sensor
- 0.96-inch SSD1306 I2C OLED
- Active buzzer (use a transistor driver if required by its current)
- Red LED + 220Ω resistor
- Two 1kΩ resistors for ECHO voltage divider
- Jumper wires
- USB data cable for uploading
- Portable power: suitable protected 3.7V battery and regulated 5V boost converter if powering through VIN

## Wiring
| Part | Connection |
|---|---|
| HC-SR04 VCC | ESP32 VIN / regulated 5V |
| HC-SR04 GND | ESP32 GND |
| HC-SR04 TRIG | GPIO 5 |
| HC-SR04 ECHO | Voltage divider midpoint -> GPIO 18 |
| OLED VCC | 3V3 |
| OLED GND | GND |
| OLED SDA | GPIO 21 |
| OLED SCL | GPIO 22 |
| Buzzer + | GPIO 19 only if within GPIO current limits; otherwise transistor driver |
| Buzzer - | GND |
| Red LED anode | GPIO 23 through 220Ω |
| Red LED cathode | GND |

### ECHO voltage divider
HC-SR04 ECHO can output about 5V, while ESP32 GPIOs are not 5V tolerant:
- ECHO -> 1kΩ resistor -> midpoint
- midpoint -> GPIO 18
- midpoint -> second 1kΩ resistor -> GND

All components must share GND.

## Power safety
- Never connect a bare 3.7V cell directly to VIN/5V.
- If using VIN, use a regulated 5V boost converter and check output with a multimeter before connecting.
- Use a protected battery and charger appropriate for the battery chemistry. Do not charge lithium batteries unattended.
- For programming, use USB. For battery demo, disconnect USB and use the regulated battery supply unless the specific board supports simultaneous supplies safely.
- A real drain installation needs waterproofing, enclosure design, electrical isolation, and field testing.

## Arduino IDE
1. Install ESP32 boards by Espressif Systems using Boards Manager.
2. Install Adafruit GFX Library, Adafruit SSD1306, and Adafruit BusIO.
3. Select ESP32 Dev Module and the correct COM port.
4. Open `esp32/smart_drain_monitor.ino`, upload, and open Serial Monitor at 115200 baud.

## Dashboard demo
Open `web/index.html` in a browser. Buttons simulate blockage/safe states locally; they do not send real alerts.

## Calibration note
The example threshold is 15 cm for demonstration only. Calibrate for your setup. Distance to a surface alone does not prove a drain is blocked.

## License
MIT
